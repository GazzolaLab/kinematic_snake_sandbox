import numpy as np
from functools import partial
import sympy as sp

# need RK23 instead of solve_ivp for compatability with pyiodide
from scipy.integrate import ode, trapz, simps

# from collections import OrderedDict

#  Local imports
from .kinematic_snake import (
    KinematicSnake,
    LiftingKinematicSnake,
    project,
)


def make_snake(froude, time_interval, snake_type, **kwargs):
    friction_coefficients = {"mu_f": None, "mu_b": None, "mu_lat": None}
    friction_coefficients.update(kwargs)

    snake = KinematicSnake(
        froude_number=froude, friction_coefficients=friction_coefficients
    )

    def activation(s, time, epsilon, wave_number):
        return epsilon * sp.cos(wave_number * sp.pi * (s + time))

    wave_number = kwargs.get("wave_number", 2.0)
    bound_activation = kwargs.get(
        "activation",
        partial(
            activation,
            epsilon=kwargs.get("epsilon", 7.0),
            wave_number=wave_number,
        ),
    )

    snake.set_activation(bound_activation)

    if snake_type == LiftingKinematicSnake:

        def lifting_activation(s, time_v, phase, lift_amp, lift_wave_number):
            if time_v > 2.0:
                liftwave = (
                    lift_amp * np.cos(lift_wave_number * np.pi * (s + phase + time_v))
                    + 1.0
                )
                np.maximum(0, liftwave, out=liftwave)
                return liftwave / trapz(liftwave, s)
            else:
                return 1.0 + 0.0 * s

        bound_lifting_activation = kwargs.get(
            "lifting_activation",
            partial(
                lifting_activation,
                phase=kwargs.get("phase", 0.26),
                lift_amp=kwargs.get("lift_amp", 1.0),
                lift_wave_number=kwargs.get("lift_wave_number", wave_number),
            ),
        )
        snake.__class__ = LiftingKinematicSnake
        snake.set_lifting_activation(bound_lifting_activation)

    return snake, wave_number


class OdeResult(dict):
    """Represents the optimization result.
    Attributes
    ----------
    x : ndarray
        The solution of the optimization.
    success : bool
        Whether or not the optimizer exited successfully.
    status : int
        Termination status of the optimizer. Its value depends on the
        underlying solver. Refer to `message` for details.
    message : str
        Description of the cause of the termination.
    fun, jac, hess: ndarray
        Values of objective function, its Jacobian and its Hessian (if
        available). The Hessians may be approximations, see the documentation
        of the function in question.
    hess_inv : object
        Inverse of the objective function's Hessian; may be an approximation.
        Not available for all solvers. The type of this attribute may be
        either np.ndarray or scipy.sparse.linalg.LinearOperator.
    nfev, njev, nhev : int
        Number of evaluations of the objective functions and of its
        Jacobian and Hessian.
    nit : int
        Number of iterations performed by the optimizer.
    maxcv : float
        The maximum constraint violation.
    Notes
    -----
    There may be additional attributes not listed above depending of the
    specific solver. Since this class is essentially a subclass of dict
    with attribute accessors, one can see which attributes are available
    using the `keys()` method.
    """

    def __getattr__(self, name):
        try:
            return self[name]
        except KeyError as e:
            raise AttributeError(name) from e

    __setattr__ = dict.__setitem__
    __delattr__ = dict.__delitem__

    def __repr__(self):
        if self.keys():
            m = max(map(len, list(self.keys()))) + 1
            return "\n".join(
                [k.rjust(m) + ": " + repr(v) for k, v in sorted(self.items())]
            )
        else:
            return self.__class__.__name__ + "()"

    def __dir__(self):
        return list(self.keys())


def solve_ivp(fun, t_span, y0, **options):
    t0, tf = float(t_span[0]), float(t_span[1])

    # METHODS = {"RK23": RK23, "RK45": RK45}

    # if method in METHODS:
    #     method = METHODS[method]

    r = ode(fun).set_integrator("lsoda")
    r.set_initial_value(y0, t0)
    # solver = method(fun, t0, y0, tf, **options)

    ts = []
    ys = []
    # just have 1000 samples, should be good enough
    dt = (tf - t0) / 1000

    while r.successful() and r.t < tf:
        ts.append(r.t)
        ys.append(r.integrate(r.t + dt))

    # status = None
    # while status is None:
    #     message = solver.step()

    #     if solver.status == "finished":
    #         status = 0
    #     elif solver.status == "failed":
    #         status = -1
    #         break

    #     t_old = solver.t_old
    #     t = solver.t
    #     y = solver.y
    #     sol = None

    #     ts.append(t)
    #     ys.append(y)

    ts = np.hstack(ts)
    ys = np.hstack(ys)

    return OdeResult(t=ts, y=ys)


def run_snake(froude, time_interval=[0.0, 5.0], snake_type=KinematicSnake, **kwargs):
    snake, wave_number = make_snake(froude, time_interval, snake_type, **kwargs)

    # Generate t_eval so that simulation stores data at this point, useful for computing
    # cycle-bases statistics and so on...
    if "activation" not in kwargs:
        # omega * time = wave-number * pi * time
        # omega = 2 * pi * freq
        # -> freq = wave_number/2 and T = 1./freq
        time_period = 2.0 / wave_number
        periods_within_interval = int(time_interval[1] / time_period)
        # t_event = np.arange(1.0, periods_within_interval) * time_period
        # events = [lambda t, y, x=x: (t - x) for x in t_event]
    else:
        time_period = None
        # events = None

    sol = solve_ivp(
        snake,
        time_interval,
        snake.state.copy().reshape(
            -1,
        ),
        method="RK23",
        # events=events,
        # t_eval = np.linspace(time_interval[0], time_interval[1], 1e4)
    )

    # RK23(
    #     snake,
    #     t0=time_interval[0],
    #     y0=snake.state.copy().reshape(
    #         -1,
    #     ),
    #     t_bound=time_interval[1],
    # )

    # # Append t_events and y_events to the final solution history
    # # Monkey patching
    # if events is not None:
    #     insert_idx = np.searchsorted(sol.t, sol.t_events)
    #     sol.t = np.insert(
    #         sol.t,
    #         insert_idx[:, 0],
    #         np.array(sol.t_events).reshape(
    #             -1,
    #         ),
    #     )
    #     sol.y = np.insert(
    #         sol.y, insert_idx[:, 0], np.squeeze(np.array(sol.y_events)).T, axis=1
    #     )

    if time_period is None:
        return snake, sol, 1.0  # Fake time-period in absence of any other data
    else:
        return snake, sol, time_period
