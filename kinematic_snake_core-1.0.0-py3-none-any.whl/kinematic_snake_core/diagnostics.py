import numpy as np
from scipy.integrate import simps, trapz
from _circle_fit import fit_circle_to_data
from kinematic_snake import (
    project,
)

# Diagnostic routines
def calculate_average_force_per_cycle(
    sim_snake,
    sol_his,
    period_start_idx,
    period_stop_idx,
    force_history_in_cycle=None,
    mag_normal_projection_of_force_history_in_cycle=None,
):
    n_steps = period_stop_idx - period_start_idx

    if force_history_in_cycle is None:
        force_history_in_cycle = np.zeros((2, n_steps))

    if mag_normal_projection_of_force_history_in_cycle is None:
        mag_normal_projection_of_force_history_in_cycle = np.zeros((n_steps))

    instantaneous_normal = np.zeros((2, n_steps))

    start_end = slice(period_start_idx, period_stop_idx)

    for step, (time, solution) in enumerate(
        zip(sol_his.t[start_end], sol_his.y[:, start_end].T)
    ):
        sim_snake.state = solution.reshape(-1, 1)
        sim_snake._construct(time)
        # tangent is along (v_x, v_y)
        # normal is along (-v_y, v_x)
        # shape is (2,1) to support project
        instantaneous_normal[:, step] = np.array([-solution[4], solution[3]])

        # Put the spatial average wihin force_history first
        force_history_in_cycle[:, step] = trapz(
            sim_snake.external_force_distribution(time), sim_snake.centerline, axis=-1
        )
        # Can be done all in one go if efficieny needed
        # mag_normal_projection_of_force_history_in_cycle[step], _ = project(
        #     force_history_in_cycle[:, step], instantaneous_normal
        # )

        # force_history_in_cycle[:, step] = trapz(
        #     np.array([[0.0], [1.0]]) + 0.0 * snake.external_force_distribution(time), snake.centerline, axis=-1
        # )

        # force_history_in_cycle[:, step] = np.cos(2.0 * np.pi * time)
    # project does (ij,ij->i) so that we put timeaxis first here
    mag_normal_projection_of_force_history_in_cycle[:], _ = np.abs(
        project(force_history_in_cycle, instantaneous_normal)
    )

    time_elapsed = sol_his.t[start_end]
    avg_force = simps(force_history_in_cycle, time_elapsed, axis=-1)
    # Take mag of force acting at each time-step and then average it out
    avg_mag_force = simps(
        np.linalg.norm(force_history_in_cycle, axis=0), time_elapsed, axis=-1
    )
    # Norm of force in the normal direction
    avg_mag_force_in_normal_direction = simps(
        mag_normal_projection_of_force_history_in_cycle, time_elapsed, axis=-1
    )
    # Should equal the period
    time_elapsed = time_elapsed[-1] - time_elapsed[0]

    return (
        avg_force / time_elapsed,
        avg_mag_force / time_elapsed,
        avg_mag_force_in_normal_direction / time_elapsed,
    )


def calculate_period_start_stop_idx(
    sol_his_time, fin_time, t_period, candidate_n_past_periods
):
    # Give a transitent of at leat 0.4*final_time
    n_past_periods = (
        candidate_n_past_periods
        if ((fin_time - candidate_n_past_periods * t_period) > 0.4 * fin_time)
        else 3
    )
    for i_period in range(n_past_periods):
        start_time = fin_time - (n_past_periods - i_period) * t_period
        # end_time = (fin_time - (n_past_periods - i_period - 1) * t_period)
        end_time = start_time + t_period
        start_period_idx = np.argmin(np.abs(sol_his_time - start_time))
        end_period_idx = np.argmin(np.abs(sol_his_time - end_time))
        # Note that +1 here. This is to accomodate slicing till the next period point
        # and not one before
        yield start_period_idx, end_period_idx + 1


def calculate_statistics_over_n_cycles(
    sim_snake, sol_his, fin_time, time_period, candidate_n_past_periods
):
    """

    Returns
    -------

    """
    # ||\int f(t) dt|| for t from n * T to (n+1) * T
    cumulative_magnitude_of_average_force = 0.0
    # \int ||f(t)|| dt for t from n * T to (n+1) * T
    cumulative_average_force_magnitude = 0.0
    # \int ||f(t) . \hat{n}|| dt for t from n * T to (n+1) * T
    cumulative_average_force_magnitude_in_normal_direction = 0.0
    n_iters = 0
    for start_idx, stop_idx in calculate_period_start_stop_idx(
        sol_his.t, fin_time, time_period, int(candidate_n_past_periods)
    ):
        (
            avg_force,
            avg_force_norm,
            avg_force_norm_in_normal_direction,
        ) = calculate_average_force_per_cycle(sim_snake, sol_his, start_idx, stop_idx)
        cumulative_magnitude_of_average_force += np.linalg.norm(avg_force)
        cumulative_average_force_magnitude += avg_force_norm
        cumulative_average_force_magnitude_in_normal_direction += (
            avg_force_norm_in_normal_direction
        )
        n_iters += 1

    return {
        "magnitude_of_average_force": cumulative_magnitude_of_average_force / n_iters,
        # Commented out as per XZ's request
        # "average_of_force_magnitude": cumulative_average_force_magnitude / n_iters,
        # "average_of_normal_force_magnitude": cumulative_average_force_magnitude_in_normal_direction
        # / n_iters,
    }


def calculate_period_idx(
    fin_time, t_period, sol_his_t, candidate_n_past_periods=8, override=False
):
    # Give a transitent of at leat 0.4*final_time
    n_past_periods = (
        candidate_n_past_periods
        if ((fin_time - candidate_n_past_periods * t_period) > 0.4 * fin_time)
        or override
        else 3
    )
    past_period_idx = np.argmin(
        np.abs(sol_his_t - (fin_time - n_past_periods * t_period))
    )
    return past_period_idx, n_past_periods * t_period


def calculate_cumulative_statistics(
    sim_snake,
    sol_his,
    past_per_index,
    past_time,
    pose_ang_his=None,
    steer_ang_his=None,
    pose_rate_his=None,
    steer_rate_his=None,
):
    """Calculates average pose angle, average pose_angle_rate
    and average turning_rate statistics, cumulated for last many cycles

    Returns
    -------

    """
    n_steps = sol_his.t.size

    if pose_ang_his is None:
        pose_ang_his = np.zeros((n_steps,))
    if steer_ang_his is None:
        steer_ang_his = np.zeros((n_steps,))
    if pose_rate_his is None:
        pose_rate_his = np.zeros((n_steps,))
    if steer_rate_his is None:
        steer_rate_his = np.zeros((n_steps,))

    for step, (time, solution) in enumerate(zip(sol_his.t, sol_his.y.T)):
        sim_snake.state = solution.reshape(-1, 1)
        sim_snake._construct(time)

        pose_ang_his[step] = sim_snake.calculate_instantaneous_pose_angle(time)
        steer_ang_his[step] = sim_snake.calculate_instantaneous_steering_angle(time)

        ## FIXME : Correct rate calculation
        #### Don't compute pose_rate analytically because it's wrong.

    pose_rate_his[0] = 0.0
    steer_rate_his[0] = 0.0
    for step in range(sol_his.t.size - 2):
        pose_rate_his[step + 1] = (pose_ang_his[step + 2] - pose_ang_his[step]) / (
            sol_his.t[step + 2] - sol_his.t[step]
        )
        steer_rate_his[step + 1] = (steer_ang_his[step + 2] - steer_ang_his[step]) / (
            sol_his.t[step + 2] - sol_his.t[step]
        )

    def averager(x):
        # calculate average statistics
        # assert(np.allclose(past_time, sol_his.t[-1] - sol_his.t[past_per_index]))
        # Try and replace with simps to see if there's any change in the results
        avg_val = (
            simps(
                x[..., past_per_index:],
                sol_his.t[past_per_index:],
                axis=-1,
            )
            / past_time
        )
        return avg_val

    # Get \dot{x} and \dot{y} to compute norms
    velocity_com = sol_his.y[3:5, ...]
    average_speed = np.linalg.norm(velocity_com, axis=0)

    # Get x and y from the point that we are considering averages from
    # to pass it onto the circle fitting algorithm
    position_com_over_averaging_window = sol_his.y[:2, past_per_index:]
    xc, yc, rc = fit_circle_to_data(position_com_over_averaging_window, verbose=False)

    # Do not trust the above radius, use the following estimate
    # Teja : In the "good" cases, it doesn't make any difference
    computed_com = np.array([xc, yc])
    integrated_distance = np.linalg.norm(
        sol_his.y[:2].reshape(2, -1) - computed_com.reshape(2, 1), 2, axis=0
    )

    return {
        "average_pose_angle": averager(pose_ang_his),
        "average_steer_angle": averager(steer_ang_his),
        # Doing this seems to accumulate error from floating point precision effects
        # Rather use Leibniz's integral theorem \int_{T_N}^{T_M} df/dt dt = f(T_M) - f(T_N)
        # "average_pose_rate": averager(pose_rate_his),
        # "average_steer_rate": averager(steer_rate_his),
        "average_pose_rate": (pose_ang_his[-1] - pose_ang_his[past_per_index])
        / past_time,
        "average_steer_rate": (steer_ang_his[-1] - steer_ang_his[past_per_index])
        / past_time,
        "average_speed": averager(average_speed),
        "fit_circle_x_center": xc,
        "fit_circle_y_center": yc,
        "fit_circle_radius": averager(integrated_distance),
        # "least_squares_fit_circle_radius": rc,
    }


def calculate_statistics(
    sim_snake, sol_his, final_time, time_period, candidate_n_past_periods=8, **kwargs
):
    # First calculate per period statistics over candidate_n_cycles
    averaged_force_stats = calculate_statistics_over_n_cycles(
        sim_snake, sol_his, final_time, time_period, candidate_n_past_periods
    )

    past_period_idx, time_elapsed_in_past_periods = calculate_period_idx(
        final_time, time_period, sol_his.t
    )

    # The compute cumulative statistics
    averaged_cumulative_stats = calculate_cumulative_statistics(
        sim_snake,
        sol_his,
        past_period_idx,
        time_elapsed_in_past_periods,
        kwargs.get("pose_ang_his", None),
        kwargs.get("steer_ang_his", None),
        kwargs.get("pose_rate_his", None),
        kwargs.get("steer_rate_his", None),
    )

    averaged_cumulative_stats.update(averaged_force_stats)
    return averaged_cumulative_stats
