import numpy as np
from functools import partial
import sympy as sp

# need RK23 instead of solve_ivp for compatability with pyiodide
from scipy.integrate import trapz, simps

# from scipy.integrate._odepack import _odepack
from .ivp import solve_ivp

# from collections import OrderedDict

#  Local imports
from .kinematic_snake import (
    KinematicSnake,
    LiftingKinematicSnake,
    project,
)


def make_snake(froude, time_interval, snake_type, **kwargs):
    friction_coefficients = {"mu_f": None, "mu_b": None, "mu_lat": None}
    friction_coefficients.update(kwargs)

    snake = KinematicSnake(
        froude_number=froude, friction_coefficients=friction_coefficients, samples=50
    )

    def activation(s, time, epsilon, wave_number):
        return epsilon * sp.cos(wave_number * sp.pi * (s + time))

    wave_number = kwargs.get("wave_number", 2.0)
    bound_activation = kwargs.get(
        "activation",
        partial(
            activation,
            epsilon=kwargs.get("epsilon", 7.0),
            wave_number=wave_number,
        ),
    )

    snake.set_activation(bound_activation)

    if snake_type == LiftingKinematicSnake:

        def lifting_activation(s, time_v, phase, lift_amp, lift_wave_number):
            if time_v > 2.0:
                liftwave = (
                    lift_amp * np.cos(lift_wave_number * np.pi * (s + phase + time_v))
                    + 1.0
                )
                np.maximum(0, liftwave, out=liftwave)
                return liftwave / trapz(liftwave, s)
            else:
                return 1.0 + 0.0 * s

        bound_lifting_activation = kwargs.get(
            "lifting_activation",
            partial(
                lifting_activation,
                phase=kwargs.get("phase", 0.26),
                lift_amp=kwargs.get("lift_amp", 1.0),
                lift_wave_number=kwargs.get("lift_wave_number", wave_number),
            ),
        )
        snake.__class__ = LiftingKinematicSnake
        snake.set_lifting_activation(bound_lifting_activation)

    return snake, wave_number


def run_snake(froude, time_interval=[0.0, 5.0], snake_type=KinematicSnake, **kwargs):
    snake, wave_number = make_snake(froude, time_interval, snake_type, **kwargs)

    # Generate t_eval so that simulation stores data at this point, useful for computing
    # cycle-bases statistics and so on...
    if "activation" not in kwargs:
        # omega * time = wave-number * pi * time
        # omega = 2 * pi * freq
        # -> freq = wave_number/2 and T = 1./freq
        time_period = 2.0 / wave_number
        periods_within_interval = int(time_interval[1] / time_period)
        # t_event = np.arange(1.0, periods_within_interval) * time_period
        # events = [lambda t, y, x=x: (t - x) for x in t_event]
    else:
        time_period = None
        # events = None

    sol = solve_ivp(
        snake,
        time_interval,
        snake.state.copy().reshape(
            -1,
        ),
        method="RK23",
        # events=events,
        # t_eval = np.linspace(time_interval[0], time_interval[1], 1e4)
        rtol=1e-2,
        atol=1e-2,
    )

    # RK23(
    #     snake,
    #     t0=time_interval[0],
    #     y0=snake.state.copy().reshape(
    #         -1,
    #     ),
    #     t_bound=time_interval[1],
    # )

    # # Append t_events and y_events to the final solution history
    # # Monkey patching
    # if events is not None:
    #     insert_idx = np.searchsorted(sol.t, sol.t_events)
    #     sol.t = np.insert(
    #         sol.t,
    #         insert_idx[:, 0],
    #         np.array(sol.t_events).reshape(
    #             -1,
    #         ),
    #     )
    #     sol.y = np.insert(
    #         sol.y, insert_idx[:, 0], np.squeeze(np.array(sol.y_events)).T, axis=1
    #     )

    if time_period is None:
        return snake, sol, 1.0  # Fake time-period in absence of any other data
    else:
        return snake, sol, time_period
